

# Validation Report for Threat Analysis with Uptycs

| SDK Version       | Generation Time          | Command Line Arguments Provided |
| :---------------- | ------------------------ | ------------------------------- |
| 51.0.1.0.695 | 2024/03/28 22:01:40 | `verbose`: True, `cmd`: validate, `package`: . |

## Results
| **Severity** | **Count** |
| :----------- | --------- |
| Critical Issues:    | <span style="color:red"> 2 </span> |
| Warnings:           | <span style="color:orange"> 2 </span>  |
| Validations Passed: | <span style="color:green"> 34  </span>   |


## App Details
| Attribute | Value |
| --------- | ----- |
| `display_name` | Threat Analysis with Uptycs |
| `name` | threat_analysis_with_uptycs |
| `version` | 1.0.0 |
| `author` | Uptycs |
| `author_email` | kadirikumar@uptycs.com |
| `install_requires` | ['resilient-circuits>=51.0.1.0.0'] |
| `description` | Responds to threats everywhere across the cloud, endpoints, containers, and K8s systems |
| `long_description` | It is a robust extension that seamlessly integrates with the Uptycs platform to retrieve real-time alerts data and analyze potential security threats.     This integration empowers security teams to proactively monitor, analyze, and respond to security incidents within their organization's IT infrastructure, ensuring timely detection and mitigation of threats. |
| `url` | https://www.uptycs.com |
| `entry_points` | {'resilient.circuits.configsection': 'C:\\Users\\kadirikumar\\Downloads\\QRADAR-SOAR-V1\\threat_analysis_with_uptycs\\threat_analysis_with_uptycs\\util\\config.py',<br> 'resilient.circuits.customize': 'C:\\Users\\kadirikumar\\Downloads\\QRADAR-SOAR-V1\\threat_analysis_with_uptycs\\threat_analysis_with_uptycs\\util\\customize.py',<br> 'resilient.circuits.selftest': 'C:\\Users\\kadirikumar\\Downloads\\QRADAR-SOAR-V1\\threat_analysis_with_uptycs\\threat_analysis_with_uptycs\\util\\selftest.py'} |
| `python_requires` | >=3.11 |
| `SOAR version` | 50.0.9097 |
| `Proxy support` | Proxies supported if running on AppHost>=1.6 |

---


## `setup.py` file validation
| Severity | Name | Description | Solution |
| --- | --- | --- | --- |

<span style="color:green">Success</span>


---


## Package files validation

### LICENSE
<span style="color:teal">INFO</span>: `LICENSE` file is valid

It is recommended to manually validate the license. Suggested formats: MIT, Apache, and BSD


### `MANIFEST.in`
<span style="color:green">Pass</span>


### `apikey_permissions.txt`
<span style="color:green">Pass</span>


### `Dockerfile, template match`
<span style="color:green">Pass</span>


### `Dockerfile, base image`
<span style="color:green">Pass</span>


### ``config.py``
<span style="color:green">Pass</span>


### ``customize.py``
<span style="color:green">Pass</span>


### `SOAR Scripts`
<span style="color:green">Pass</span>


### `README.md`
<span style="color:green">Pass</span>


### `app_logo.png`
<span style="color:green">Pass</span>


### `company_logo.png`
<span style="color:green">Pass</span>


### LICENSE
<span style="color:green">Pass</span>

 
---
 

## Payload samples validation

### `payload_samples\uptycs_api`
<span style="color:green">Pass</span>

 
---
 

## `resilient-circuits` selftest
<span style="color:red">CRITICAL</span>: While running selftest.py, `resilient-circuits` failed to connect to server. Details:

	...
	2024-03-28 22:01:00,238 INFO [stomp_component] [resilient_circuits] Subscribe to message destination actions.201.fn_uptycs_api
	2024-03-28 22:01:00,779 ERROR [actions_component] [resilient_circuits] STOMP listener: Error:
	b`User c984c1fd-67c0-4578-8d70-bd9343c6a808 is not authorized to read from queue://actions.201.fn_uptycs_api`
	2024-03-28 22:01:01,974 INFO [actions_component] [resilient_circuits] SelftestTerminateEvent, exiting resilient-circuits
	
	ERROR: could not connect to SOAR at `169.60.89.124`.
	Reason: `c984c1fd-67c0-4578-8d70-bd9343c6a808` is not authorized to read from the App`s Message Destination
	Error Code: 32




---
 

## tox tests
<span style="color:red">CRITICAL</span>: 3 tests failed. Details:

	self = <test_funct_uptycs_api.TestUptycsApi object at 0x000001DCF2CE7DD0>
	
	    def test_function_definition(self):
	        """ Test that the package provides customization_data that defines the function """
	        func = get_function_definition(PACKAGE_NAME, FUNCTION_NAME)
	>       assert func is not None
	E       assert None is not None
	
	tests\test_funct_uptycs_api.py:48: AssertionError
	
	---
	
	self = <test_funct_uptycs_api.TestUptycsApi object at 0x000001DCF42970D0>
	circuits_app = <pytest_resilient_circuits.resilient_circuits_fixtures.ResilientCircuits object at 0x000001DCF582FE90>
	mock_inputs = {`uptycs_api_endpoint`: `/`, `uptycs_api_method`: `GET`, `uptycs_api_payload`: `{}`}
	
	    @pytest.mark.parametrize("mock_inputs", [(mock_inputs_1)])
	    def test_domain_details(self, circuits_app, mock_inputs):
	        """ Test calling with sample values for the parameters """
	    
	        results = call_uptycs_api_function(circuits_app, mock_inputs)
	>       response = results[`content`]
	E       TypeError: `NoneType` object is not subscriptable
	
	tests\test_funct_uptycs_api.py:67: TypeError
	
	---
	
	self = <test_funct_uptycs_api.TestUptycsApi object at 0x000001DCF583CD50>
	circuits_app = <pytest_resilient_circuits.resilient_circuits_fixtures.ResilientCircuits object at 0x000001DCF582FE90>
	mock_inputs = {`uptycs_api_endpoint`: `/assets/count`, `uptycs_api_method`: `GET`, `uptycs_api_payload`: `{}`}
	
	    @pytest.mark.parametrize("mock_inputs", [(mock_inputs_2)])
	    def test_assets_count(self, circuits_app, mock_inputs):
	        """ Test with assets count API """
	    
	        results = call_uptycs_api_function(circuits_app, mock_inputs)
	>       response = results[`content`]
	E       TypeError: `NoneType` object is not subscriptable
	
	tests\test_funct_uptycs_api.py:81: TypeError
	
	---
	
	


Run with the `-v` flag to see more information

<span style="color:orange">WARNING</span>: Unsupported tox environment found in envlist in `tox.ini` file

Tests must be configured to run only with tox environments `py36` or greater



---
 

## Pylint Scan
<span style="color:orange">WARNING</span>: The Pylint score was 9.81/10. Details:

	************* Module c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `print-statement` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `parameter-unpacking` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `unpacking-in-except` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `old-raise-syntax` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `backtick` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `import-star-module-level` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `apply-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `basestring-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `buffer-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `cmp-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `coerce-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `execfile-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `file-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `long-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `raw_input-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `reduce-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `standarderror-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `unicode-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `xrange-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `coerce-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `delslice-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `getslice-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `setslice-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `no-absolute-import` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `old-division` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `dict-iter-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `dict-view-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `next-method-called` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `metaclass-assignment` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `indexing-exception` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `raising-string` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `reload-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `oct-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `hex-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `nonzero-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `cmp-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `input-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `round-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `intern-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `unichr-builtin` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `map-builtin-not-iterating` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `zip-builtin-not-iterating` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `range-builtin-not-iterating` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `filter-builtin-not-iterating` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `using-cmp-argument` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `div-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `idiv-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `rdiv-method` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `exception-message-attribute` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `invalid-str-codec` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `sys-max-int` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `bad-python3-import` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `deprecated-string-function` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `deprecated-str-translate-call` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `deprecated-itertools-function` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `deprecated-types-field` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `next-method-defined` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `dict-items-not-iterating` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `dict-keys-not-iterating` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `dict-values-not-iterating` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `deprecated-operator-function` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `deprecated-urllib-function` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `xreadlines-attribute` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `deprecated-sys-function` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `exception-escape` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	refactor c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Useless option value for `--disable`, `comprehension-escape` was removed from pylint, see https://github.com/pylint-dev/pylint/pull/4942.
	warning c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Unknown option value for `--disable`, expected a valid pylint message and got `long-suffix`
	warning c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Unknown option value for `--disable`, expected a valid pylint message and got `old-ne-operator`
	warning c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Unknown option value for `--disable`, expected a valid pylint message and got `old-octal-literal`
	warning c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Unknown option value for `--disable`, expected a valid pylint message and got `non-ascii-bytes-literal`
	warning c:\Users\kadirikumar\Downloads\QRADAR-SOAR-V1\.venv\Lib\site-packages\resilient_sdk\data\validate\.pylintrc:1:0: Unknown option value for `--disable`, expected a valid pylint message and got `eq-without-hash`
	************* Module threat_analysis_with_uptycs.components.funct_uptycs_api
	warning threat_analysis_with_uptycs.components.funct_uptycs_api:97:8: No exception type(s) specified
	warning threat_analysis_with_uptycs.components.funct_uptycs_api:91:12: Use lazy % formatting in logging functions
	
	------------------------------------------------------------------
	Your code has been rated at 9.81/10 (previous run: 9.81/10, +0.00)
	
	





---
 

## Bandit Scan
<span style="color:teal">INFO</span>: Bandit scan passed with no issues

Run again with `-v` to see the full bandit output



---
 