# -*- coding: utf-8 -*-
"""Tests using pytest_resilient_circuits"""
import pytest
from mock import patch
from resilient_circuits.util import get_config_data, get_function_definition
from resilient_circuits import SubmitTestFunction, FunctionResult

PACKAGE_NAME = "threat_analysis_with_uptycs"
FUNCTION_NAME = "uptycs_api"

# Read the default configuration-data section from the package
config_data = get_config_data(PACKAGE_NAME)

# Provide a simulation of the Resilient REST API (uncomment to connect to a real appliance)
resilient_mock = "pytest_resilient_circuits.BasicResilientMock"


def call_uptycs_api_function(circuits_app, function_params, timeout=10):
    # Create the SubmitTestFunction event
    evt = SubmitTestFunction(FUNCTION_NAME, function_params)

    # Fire the event to the FunctionComponent
    circuits_app.manager.fire(evt)

    # Wait for the result event from the FunctionComponent
    event = circuits_app.watcher.wait("uptycs_api_result", parent=evt, timeout=timeout)

    # Validate the result
    assert event
    assert isinstance(event.kwargs["result"], FunctionResult)

    # Return the result value
    return event.kwargs["result"].value


class TestUptycsApi:
    """ Tests for the uptycs_api function"""

    def test_function_definition(self):
        """ Test that the package provides customization_data that defines the function """
        func = get_function_definition(PACKAGE_NAME, FUNCTION_NAME)
        assert func is not None

    mock_inputs_1 = {
        "uptycs_api_method": "GET",
        "uptycs_api_payload": "{}",
        "uptycs_api_endpoint": "/"
    }

    mock_inputs_2 = {
        "uptycs_api_method": "GET",
        "uptycs_api_payload": "{}",
        "uptycs_api_endpoint": "/assets/count"
    }

    @pytest.mark.parametrize("mock_inputs", [
        (mock_inputs_1),
        (mock_inputs_2)
    ])
    @patch("requests.request")
    def test_success(self, mocked_requests, circuits_app, mock_inputs):
        """ Test calling with sample values for the parameters """
        # Set up the mock response
        mocked_requests.return_value.status_code = 200
        mocked_requests.return_value.json.return_value = {"data": "mock_response"}

        results = call_uptycs_api_function(circuits_app, mock_inputs)
        assert results == {"data": "mock_response"}